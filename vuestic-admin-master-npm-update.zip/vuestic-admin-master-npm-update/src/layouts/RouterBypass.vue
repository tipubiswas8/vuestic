<template>
  <div class="max-w-7xl mx-auto">
    <RouterView></RouterView>
  </div>
</template>

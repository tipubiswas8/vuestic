export const buttonStyles = {
  '--va-button-font-size': '14px',
  '--va-button-line-height': '20px',
}
